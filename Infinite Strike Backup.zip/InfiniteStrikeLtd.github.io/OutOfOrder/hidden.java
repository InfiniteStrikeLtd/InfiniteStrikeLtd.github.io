public class hidden{

    public static void main(Sting args[]){
        System.out.println("You found the secret file!");
    }
    
}